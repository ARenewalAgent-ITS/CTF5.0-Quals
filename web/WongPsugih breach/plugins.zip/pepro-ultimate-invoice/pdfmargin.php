<?php

return "ARA5{Ju5t_L34";
