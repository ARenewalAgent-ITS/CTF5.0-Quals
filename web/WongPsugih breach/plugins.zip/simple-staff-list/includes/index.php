<?php
/**
 * Silence is golden
 *
 * @package    Simple_Staff_List
 */
